# Solitary Confinement — Safe Multiplayer Prototype

A safe prison-themed web-app adaptation inspired by the **Jack of Hearts / Solitary Confinement** social deduction structure.

This is **not dangerous**: the “collar explosion” is a stylized neon **game over** animation. Elimination means the player is out of the round/game.

## Features

- Room creation and room-code joining
- Real-time multiplayer with Socket.IO
- Random secret Jack of Hearts selection inside a prison-themed interface
- Hidden role display: only you know if you are the Jack
- Round-based card dealing from a real shuffled 52-card deck
- Players can see other players' cards, but not their own
- Public chat
- Private/secret whispers
- “Tell selected player their card” action, including the ability to lie
- Declaration phase: each player locks the card they believe they hold
- Automatic elimination for wrong declarations
- Stylized neon collar game-over animation
- Host controls: start game, next round, reset room
- True silent spectator state for eliminated players
- Eliminated players cannot send public messages, private whispers, or card claims
- Private targets only include alive players
- No duplicate cards can be dealt in the same round
- Mobile-friendly interface

## How to run locally

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Install dependencies:

```bash
npm install
```

4. Start the server:

```bash
npm start
```

5. Open this URL in your browser:

```bash
http://localhost:3000
```

6. To play on multiple devices on the same Wi-Fi, find your computer's local IP address and open:

```bash
http://YOUR_LOCAL_IP:3000
```

Example:

```bash
http://192.168.1.20:3000
```

## Basic game flow

1. One player creates a room.
2. Other players join with the room code.
3. The host starts the game.
4. The server secretly chooses one player as the Jack of Hearts.
5. Each round, every alive player receives one card from a freshly shuffled 52-card deck.
6. No two alive players can receive the same card in a round.
7. You can see everyone else's card, but not your own.
8. Players communicate publicly or privately while alive.
9. Each player declares their own card.
10. Wrong declarations are eliminated.
11. Eliminated players become silent spectators and cannot communicate with active players.
12. Citizens win if the Jack is eliminated.
13. The Jack wins if they survive until only two players remain.

## Suggested live rules

For maximum tension:

- No screenshots.
- No showing screens to other players.
- Players may talk out loud, whisper, or use the app chat.
- Allow lying, fake alliances, and false card claims.
- Keep the game respectful: deception is inside the game only.

## Safe design note

The app avoids graphic violence. The collar animation is abstract and symbolic, like an arcade elimination effect.

## Latest patch

- Replaced independent random card generation with a real shuffled deck.
- Guaranteed unique cards per round.
- Blocked eliminated players from public chat, private chat, and card-claim actions at the server level.
- Removed eliminated players from private-message/card-claim target lists.



## UI fixes included

- Chat panel no longer overflows on desktop or smaller screens.
- Private chat and card-claim controls stack safely when space is limited.
- Empty target lists now show "No available prisoners".
- Lobby status shows player count instead of "alive" count.
- Start Game is disabled until the room reaches the minimum player count.
